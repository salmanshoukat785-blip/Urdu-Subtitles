package com.urdusubs.app

/**
 * The user's own word list, one entry per line:
 *   "old = new"   swaps a word in the original text before it is translated
 *   "old => new"  fixes a word in the Urdu result after translation
 * Lines starting with # are ignored.
 */
class Dictionary {

    private var raw: String? = null
    private var before: List<Pair<Regex, String>> = emptyList()
    private var after: List<Pair<String, String>> = emptyList()

    fun update(newRaw: String) {
        if (newRaw == raw) return
        raw = newRaw

        val beforeList = ArrayList<Pair<Regex, String>>()
        val afterList = ArrayList<Pair<String, String>>()

        for (line in newRaw.lines()) {
            val trimmed = line.trim()
            if (trimmed.isEmpty() || trimmed.startsWith("#")) continue

            val arrow = trimmed.indexOf("=>")
            if (arrow > 0) {
                val fromText = trimmed.substring(0, arrow).trim()
                val toText = trimmed.substring(arrow + 2).trim()
                if (fromText.isNotEmpty()) afterList.add(Pair(fromText, toText))
                continue
            }

            val equals = trimmed.indexOf('=')
            if (equals > 0) {
                val fromText = trimmed.substring(0, equals).trim()
                val toText = trimmed.substring(equals + 1).trim()
                if (fromText.isNotEmpty() && toText.isNotEmpty()) {
                    // Whole words only, in any script.
                    val pattern = "(?<![\\p{L}\\p{N}])" + Regex.escape(fromText) + "(?![\\p{L}\\p{N}])"
                    beforeList.add(Pair(Regex(pattern, RegexOption.IGNORE_CASE), toText))
                }
            }
        }

        before = beforeList
        after = afterList
    }

    fun applyBefore(text: String): String {
        var out = text
        for (entry in before) {
            out = entry.first.replace(out, Regex.escapeReplacement(entry.second))
        }
        return out
    }

    fun applyAfter(text: String): String {
        var out = text
        for (entry in after) {
            out = out.replace(entry.first, entry.second)
        }
        return out
    }
}
