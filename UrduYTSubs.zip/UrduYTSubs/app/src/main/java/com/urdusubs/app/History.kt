package com.urdusubs.app

import android.content.Context
import java.io.File

/**
 * The captions translated so far (newest last). Kept in memory and saved to a small file, so
 * the app can show them, export them as .srt / .txt and report the translation delay.
 */
object History {
    class Entry(
        val time: Long,
        val pkg: String,
        val original: String,
        var urdu: String,
        var latencyMs: Long
    )

    private const val MAX = 500
    private const val FILE = "history.tsv"
    private val items = ArrayList<Entry>()
    private var loaded = false

    @Synchronized
    fun load(context: Context) {
        if (loaded) return
        loaded = true
        try {
            val file = File(context.filesDir, FILE)
            if (!file.exists()) return
            file.readLines(Charsets.UTF_8).forEach { line ->
                val f = line.split('\t')
                if (f.size >= 5) {
                    items.add(
                        Entry(
                            f[0].toLongOrNull() ?: 0L, f[1], unescape(f[3]), unescape(f[4]),
                            f[2].toLongOrNull() ?: 0L
                        )
                    )
                }
            }
        } catch (e: Exception) {
            // A damaged history file is not worth failing for.
        }
    }

    @Synchronized
    fun save(context: Context) {
        try {
            val text = items.joinToString("\n") {
                "${it.time}\t${it.pkg}\t${it.latencyMs}\t${escape(it.original)}\t${escape(it.urdu)}"
            }
            File(context.filesDir, FILE).writeText(text, Charsets.UTF_8)
        } catch (e: Exception) {
            // Ignore; the next save tries again.
        }
    }

    /** Adds a caption, or updates the last one when the same caption gets a better translation. */
    @Synchronized
    fun add(pkg: String, original: String, urdu: String, latencyMs: Long) {
        val last = items.lastOrNull()
        if (last != null && last.original == original) {
            last.urdu = urdu
            last.latencyMs = latencyMs
            return
        }
        items.add(Entry(System.currentTimeMillis(), pkg, original, urdu, latencyMs))
        while (items.size > MAX) items.removeAt(0)
    }

    @Synchronized
    fun snapshot(): List<Entry> = ArrayList(items)

    @Synchronized
    fun clear(context: Context) {
        items.clear()
        save(context)
    }

    /** Average translation delay over the last 30 captions: (count, milliseconds). */
    @Synchronized
    fun averageLatency(): Pair<Int, Long> {
        val recent = items.takeLast(30).filter { it.latencyMs > 0 }
        if (recent.isEmpty()) return Pair(0, 0L)
        return Pair(recent.size, recent.sumOf { it.latencyMs } / recent.size)
    }

    /** SubRip file. Times count from the first caption, so they follow the viewing time. */
    fun toSrt(list: List<Entry>): String {
        if (list.isEmpty()) return ""
        val base = list[0].time
        val sb = StringBuilder()
        for (i in list.indices) {
            val start = list[i].time - base
            val next = if (i + 1 < list.size) list[i + 1].time - base else Long.MAX_VALUE
            val end = if (next - start in 1L..6000L) next else start + 4000
            sb.append(i + 1).append('\n')
            sb.append(stamp(start)).append(" --> ").append(stamp(end)).append('\n')
            sb.append(list[i].urdu).append("\n\n")
        }
        return sb.toString()
    }

    fun toText(list: List<Entry>): String =
        list.joinToString("\n\n") { it.original + "\n" + it.urdu }

    private fun stamp(ms: Long): String {
        val h = ms / 3600000
        val m = ms / 60000 % 60
        val s = ms / 1000 % 60
        val milli = ms % 1000
        return String.format("%02d:%02d:%02d,%03d", h, m, s, milli)
    }

    private fun escape(s: String) =
        s.replace("\\", "\\\\").replace("\t", "\\t").replace("\n", "\\n").replace("\r", "")

    private fun unescape(s: String): String {
        val sb = StringBuilder()
        var i = 0
        while (i < s.length) {
            val c = s[i]
            if (c == '\\' && i + 1 < s.length) {
                when (s[i + 1]) {
                    't' -> sb.append('\t')
                    'n' -> sb.append('\n')
                    else -> sb.append(s[i + 1])
                }
                i += 2
            } else {
                sb.append(c)
                i++
            }
        }
        return sb.toString()
    }
}
