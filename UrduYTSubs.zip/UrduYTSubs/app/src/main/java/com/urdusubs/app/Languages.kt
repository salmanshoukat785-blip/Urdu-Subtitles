package com.urdusubs.app

import java.util.Locale

/** Source languages offered in the language filter and the model manager. */
object Languages {
    val CODES = listOf(
        "en", "hi", "ar", "fa", "es", "fr", "de", "tr",
        "ru", "zh", "ja", "ko", "id", "pt", "it", "bn"
    )

    /** The language's name written in [uiLocale] (Urdu names when the app is in Urdu). */
    fun name(code: String, uiLocale: Locale): String {
        val n = Locale.forLanguageTag(code).getDisplayLanguage(uiLocale)
        return if (n.isEmpty()) code else n.replaceFirstChar { it.uppercase() }
    }
}
