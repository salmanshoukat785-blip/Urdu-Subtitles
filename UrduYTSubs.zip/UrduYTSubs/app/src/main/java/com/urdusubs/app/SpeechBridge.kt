package com.urdusubs.app

/**
 * Connects the audio listener (AudioCaptureService) with the subtitle service. Both live in
 * this app's process, so a plain object is enough. Callbacks arrive on the main thread.
 */
object SpeechBridge {
    /** Called with the recognised English text; isFinal = false for a sentence still in progress. */
    @Volatile
    var listener: ((text: String, isFinal: Boolean) -> Unit)? = null

    /** True while the audio listener is running. */
    @Volatile
    var running = false
}
