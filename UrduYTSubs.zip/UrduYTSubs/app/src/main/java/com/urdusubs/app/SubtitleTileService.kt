package com.urdusubs.app

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** Quick Settings tile that turns the Urdu subtitles on or off. */
class SubtitleTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        refresh()
    }

    override fun onClick() {
        super.onClick()
        val prefs = Prefs.get(this)
        val now = prefs.getBoolean(Prefs.KEY_ENABLED, true)
        prefs.edit().putBoolean(Prefs.KEY_ENABLED, !now).apply()
        refresh()
    }

    private fun refresh() {
        val tile = qsTile ?: return
        val on = Prefs.get(this).getBoolean(Prefs.KEY_ENABLED, true)
        tile.state = if (on) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.updateTile()
    }
}
