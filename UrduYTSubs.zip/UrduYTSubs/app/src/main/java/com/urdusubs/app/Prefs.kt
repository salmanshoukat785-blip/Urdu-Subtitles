package com.urdusubs.app

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private const val NAME = "urdu_subs"

    const val KEY_ENABLED = "enabled"
    const val KEY_DEBUG = "debug"
    const val KEY_ONLINE = "online"
    const val KEY_SIZE = "size"
    const val KEY_POS_PORTRAIT = "pos_portrait"
    const val KEY_POS_LAND = "pos_land"
    const val KEY_LOG = "debug_log"
    const val KEY_LOG_CLEARS = "debug_log_clears"

    const val KEY_MODE = "mode"
    const val KEY_SHIFT = "shift"

    // Where the Urdu line goes relative to YouTube's English caption.
    const val MODE_ABOVE = 0
    const val MODE_BELOW = 1
    const val MODE_COVER = 2

    const val DEF_MODE = MODE_BELOW
    const val DEF_SHIFT = 50 // slider middle = no extra shift

    const val DEF_SIZE = 15
    const val DEF_POS_PORTRAIT = 62
    const val DEF_POS_LAND = 8

    fun get(context: Context): SharedPreferences =
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE)
}
