package com.urdusubs.app

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private const val NAME = "urdu_subs"

    const val KEY_ENABLED = "enabled"
    const val KEY_DEBUG = "debug"
    const val KEY_SIZE = "size"
    const val KEY_POS_PORTRAIT = "pos_portrait"
    const val KEY_POS_LAND = "pos_land"
    const val KEY_LOG = "debug_log"
    const val KEY_LOG_CLEARS = "debug_log_clears"

    const val DEF_SIZE = 20
    const val DEF_POS_PORTRAIT = 62
    const val DEF_POS_LAND = 8

    fun get(context: Context): SharedPreferences =
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE)
}
