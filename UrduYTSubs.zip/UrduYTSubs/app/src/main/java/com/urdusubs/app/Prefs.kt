package com.urdusubs.app

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private const val NAME = "urdu_subs"

    // ---- Global settings
    const val KEY_ENABLED = "enabled"
    const val KEY_DEBUG = "debug"
    const val KEY_ONLINE = "online"
    const val KEY_CONTEXT = "context"
    const val KEY_MOVE_MODE = "move_mode"
    const val KEY_DICT = "dictionary"
    const val KEY_SEEN_APPS = "seen_apps"
    const val KEY_LANG_INIT = "lang_init"
    const val KEY_AUTOHIDE = "autohide"
    const val KEY_ALL_APPS = "all_apps"
    const val KEY_CUSTOM_IDS = "custom_ids"
    const val KEY_LOG = "debug_log"
    const val KEY_LOG_CLEARS = "debug_log_clears"
    const val KEY_POS_PORTRAIT = "pos_portrait"
    const val KEY_POS_LAND = "pos_land"

    // ---- Settings that can be different for each app ("profile")
    const val KEY_SIZE = "size"
    const val KEY_MODE = "mode"
    const val KEY_SHIFT = "shift"
    const val KEY_BG_COLOR = "bg_color"
    const val KEY_BG_ALPHA = "bg_alpha"
    const val KEY_TEXT_COLOR = "text_color"
    const val KEY_BOLD = "bold"
    const val KEY_SHADOW = "shadow"
    const val KEY_HOLD = "hold"
    const val KEY_DX = "drag_dx"
    const val KEY_DY = "drag_dy"

    val PROFILE_KEYS = arrayOf(
        KEY_SIZE, KEY_MODE, KEY_SHIFT, KEY_BG_COLOR, KEY_BG_ALPHA,
        KEY_TEXT_COLOR, KEY_BOLD, KEY_SHADOW, KEY_HOLD, KEY_DX, KEY_DY
    )

    // Background colour choices for the Urdu subtitle box (ARGB, fully opaque here;
    // the opacity slider decides how see-through it is).
    val BG_COLORS = intArrayOf(
        0xFF000000.toInt(), // black
        0xFF0D2B5B.toInt(), // dark blue
        0xFF0B4F2A.toInt(), // dark green
        0xFF6B0F1A.toInt(), // dark red
        0xFF3D1A6B.toInt(), // purple
        0xFF424242.toInt(), // grey
        0xFFFFD600.toInt(), // yellow
        0xFFFFFFFF.toInt()  // white
    )

    // Text colour choices. Index 0 means "automatic" (black or white, whichever reads best).
    val TEXT_COLORS = intArrayOf(
        0,
        0xFFFFFFFF.toInt(), // white
        0xFF000000.toInt(), // black
        0xFFFFEB3B.toInt(), // yellow
        0xFF80DEEA.toInt(), // cyan
        0xFFA5D6A7.toInt()  // light green
    )

    const val DEF_BG_COLOR = 0
    const val DEF_BG_ALPHA = 80 // percent
    const val DEF_TEXT_COLOR = 0
    const val DEF_HOLD = 4 // seconds

    // Where the Urdu line goes relative to the English caption.
    const val MODE_ABOVE = 0
    const val MODE_BELOW = 1
    const val MODE_COVER = 2

    const val DEF_MODE = MODE_BELOW
    const val DEF_SHIFT = 50 // slider middle = no extra shift

    const val DEF_SIZE = 15
    const val DEF_POS_PORTRAIT = 62
    const val DEF_POS_LAND = 8

    fun get(context: Context): SharedPreferences =
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    /** Key for a per-app setting. An empty package means the default profile. */
    fun key(base: String, pkg: String): String = if (pkg.isEmpty()) base else "$base@$pkg"

    /** Per-app value if that app has its own, otherwise the default profile's value. */
    fun getInt(p: SharedPreferences, base: String, pkg: String, def: Int): Int {
        val k = key(base, pkg)
        return if (p.contains(k)) p.getInt(k, def) else p.getInt(base, def)
    }

    fun getBool(p: SharedPreferences, base: String, pkg: String, def: Boolean): Boolean {
        val k = key(base, pkg)
        return if (p.contains(k)) p.getBoolean(k, def) else p.getBoolean(base, def)
    }
}
