package com.urdusubs.app

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private const val NAME = "urdu_subs"

    const val KEY_ENABLED = "enabled"
    const val KEY_DEBUG = "debug"
    const val KEY_ONLINE = "online"
    const val KEY_SIZE = "size"
    const val KEY_POS_PORTRAIT = "pos_portrait"
    const val KEY_POS_LAND = "pos_land"
    const val KEY_LOG = "debug_log"
    const val KEY_LOG_CLEARS = "debug_log_clears"

    const val KEY_LANG_INIT = "lang_init"
    const val KEY_AUTOHIDE = "autohide"
    const val KEY_ALL_APPS = "all_apps"
    const val KEY_CUSTOM_IDS = "custom_ids"

    const val KEY_BG_COLOR = "bg_color"
    const val KEY_BG_ALPHA = "bg_alpha"

    // Background colour choices for the Urdu subtitle box (ARGB, fully opaque here;
    // the opacity slider decides how see-through it is).
    val BG_COLORS = intArrayOf(
        0xFF000000.toInt(), // black
        0xFF0D2B5B.toInt(), // dark blue
        0xFF0B4F2A.toInt(), // dark green
        0xFF6B0F1A.toInt(), // dark red
        0xFF3D1A6B.toInt(), // purple
        0xFF424242.toInt(), // grey
        0xFFFFD600.toInt(), // yellow
        0xFFFFFFFF.toInt()  // white
    )
    const val DEF_BG_COLOR = 0
    const val DEF_BG_ALPHA = 80 // percent

    const val KEY_MODE = "mode"
    const val KEY_SHIFT = "shift"

    // Where the Urdu line goes relative to YouTube's English caption.
    const val MODE_ABOVE = 0
    const val MODE_BELOW = 1
    const val MODE_COVER = 2

    const val DEF_MODE = MODE_BELOW
    const val DEF_SHIFT = 50 // slider middle = no extra shift

    const val DEF_SIZE = 15
    const val DEF_POS_PORTRAIT = 62
    const val DEF_POS_LAND = 8

    fun get(context: Context): SharedPreferences =
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE)
}
