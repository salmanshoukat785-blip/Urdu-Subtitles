package com.urdusubs.app

import android.content.Context
import android.os.Handler
import android.os.Looper
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.zip.ZipInputStream

/** The offline English speech model (Vosk small, about 40 MB), downloaded once to the phone. */
object ModelStore {
    private const val NAME = "vosk-model-small-en-us-0.15"
    private const val URL_ZIP = "https://alphacephei.com/vosk/models/$NAME.zip"

    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    @Volatile
    var downloading = false

    fun modelDir(context: Context): File = File(context.filesDir, NAME)

    fun isReady(context: Context): Boolean = File(modelDir(context), "am/final.mdl").exists()

    /** onProgress gets 0..100 (or -1 when the size is unknown); onDone gets true on success. */
    fun download(context: Context, onProgress: (Int) -> Unit, onDone: (Boolean) -> Unit) {
        if (downloading) return
        downloading = true
        val appContext = context.applicationContext
        io.execute {
            var ok = false
            val temp = File(appContext.filesDir, "$NAME.tmp")
            try {
                temp.deleteRecursively()
                temp.mkdirs()
                val connection = URL(URL_ZIP).openConnection() as HttpURLConnection
                connection.connectTimeout = 15000
                connection.readTimeout = 30000
                val total = connection.contentLengthLong
                var read = 0L
                var lastPercent = -2
                ZipInputStream(connection.inputStream.buffered()).use { zip ->
                    val buffer = ByteArray(64 * 1024)
                    var entry = zip.nextEntry
                    while (entry != null) {
                        val out = File(temp, entry.name)
                        // Refuse entries that would be written outside the model folder.
                        if (!out.canonicalPath.startsWith(temp.canonicalPath + File.separator)) {
                            throw IllegalStateException("bad zip entry")
                        }
                        if (entry.isDirectory) {
                            out.mkdirs()
                        } else {
                            out.parentFile?.mkdirs()
                            FileOutputStream(out).use { fos ->
                                while (true) {
                                    val n = zip.read(buffer)
                                    if (n < 0) break
                                    fos.write(buffer, 0, n)
                                    read += n
                                }
                            }
                        }
                        // The zip is compressed, so this is only a rough estimate of progress.
                        val percent = if (total > 0) minOf(99, (read * 100 / (total * 15 / 10)).toInt()) else -1
                        if (percent != lastPercent) {
                            lastPercent = percent
                            main.post { onProgress(percent) }
                        }
                        entry = zip.nextEntry
                    }
                }
                val target = modelDir(appContext)
                target.deleteRecursively()
                ok = File(temp, "$NAME/am/final.mdl").exists() &&
                    File(temp, NAME).renameTo(target)
            } catch (e: Exception) {
                ok = false
            } finally {
                temp.deleteRecursively()
                downloading = false
            }
            main.post { onDone(ok) }
        }
    }

    fun delete(context: Context) {
        modelDir(context).deleteRecursively()
    }
}
