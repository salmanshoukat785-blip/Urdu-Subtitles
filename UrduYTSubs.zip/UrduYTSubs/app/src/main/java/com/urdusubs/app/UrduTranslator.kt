package com.urdusubs.app

import android.os.Handler
import android.os.Looper
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

/**
 * Translates a caption line to Urdu.
 *
 * Online mode (better quality) asks Google Translate's public web endpoint; if that fails
 * (no internet, blocked, changed) it silently falls back to the on-device ML Kit translator.
 * All callbacks arrive on the main thread.
 */
class UrduTranslator {

    /** Set from the app's "online translation" switch before each translation. */
    var onlineEnabled = true

    private val identifier = LanguageIdentification.getClient()
    private val translators = HashMap<String, Translator>()
    private var lastLang: String? = null

    private val io = Executors.newFixedThreadPool(2)
    private val main = Handler(Looper.getMainLooper())

    private val cache = object : LinkedHashMap<String, String>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?): Boolean =
            size > 200
    }

    /** onResult gets the Urdu text, or null if it could not be translated. */
    fun translate(text: String, onResult: (String?) -> Unit) {
        cache[text]?.let {
            onResult(it)
            return
        }

        if (!onlineEnabled) {
            translateOffline(text, onResult)
            return
        }

        io.execute {
            val online = fetchOnline(text)
            main.post {
                if (online != null) {
                    cache[text] = online
                    onResult(online)
                } else {
                    translateOffline(text, onResult)
                }
            }
        }
    }

    // ------------------------------------------------------------------- online

    private fun fetchOnline(text: String): String? {
        var connection: HttpURLConnection? = null
        try {
            val url = URL(
                "https://translate.googleapis.com/translate_a/single" +
                    "?client=gtx&sl=auto&tl=ur&dt=t&q=" + URLEncoder.encode(text, "UTF-8")
            )
            connection = url.openConnection() as HttpURLConnection
            connection.connectTimeout = 4000
            connection.readTimeout = 4000
            connection.setRequestProperty("User-Agent", "Mozilla/5.0")
            if (connection.responseCode != 200) return null

            val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val parts = JSONArray(body).getJSONArray(0)
            val result = StringBuilder()
            for (i in 0 until parts.length()) {
                val part = parts.optJSONArray(i) ?: continue
                result.append(part.optString(0, ""))
            }
            return result.toString().trim().ifEmpty { null }
        } catch (e: Exception) {
            return null
        } finally {
            connection?.disconnect()
        }
    }

    // ------------------------------------------------------------------ offline

    private fun translateOffline(text: String, onResult: (String?) -> Unit) {
        identifier.identifyLanguage(text)
            .addOnSuccessListener { detected ->
                // Short caption fragments are often "und"; reuse the last known language.
                val lang = if (detected == "und") lastLang else detected
                if (lang == null) {
                    onResult(null)
                    return@addOnSuccessListener
                }
                lastLang = lang

                if (lang == TranslateLanguage.URDU) {
                    onResult(text)
                    return@addOnSuccessListener
                }

                val source = TranslateLanguage.fromLanguageTag(lang)
                if (source == null) {
                    onResult(null)
                    return@addOnSuccessListener
                }

                val translator = translators.getOrPut(source) {
                    Translation.getClient(
                        TranslatorOptions.Builder()
                            .setSourceLanguage(source)
                            .setTargetLanguage(TranslateLanguage.URDU)
                            .build()
                    )
                }

                translator.downloadModelIfNeeded(DownloadConditions.Builder().build())
                    .addOnSuccessListener {
                        translator.translate(text)
                            .addOnSuccessListener { out ->
                                cache[text] = out
                                onResult(out)
                            }
                            .addOnFailureListener { onResult(null) }
                    }
                    .addOnFailureListener { onResult(null) }
            }
            .addOnFailureListener { onResult(null) }
    }

    fun close() {
        io.shutdown()
        translators.values.forEach { it.close() }
        translators.clear()
        identifier.close()
    }

    companion object {
        /** Downloads the English, Hindi and Arabic -> Urdu models (Urdu model is shared). */
        fun downloadCommonModels(onProgress: (done: Int, total: Int, failed: Int) -> Unit) {
            val sources = listOf(
                TranslateLanguage.ENGLISH,
                TranslateLanguage.HINDI,
                TranslateLanguage.ARABIC
            )
            var done = 0
            var failed = 0
            sources.forEach { source ->
                val translator = Translation.getClient(
                    TranslatorOptions.Builder()
                        .setSourceLanguage(source)
                        .setTargetLanguage(TranslateLanguage.URDU)
                        .build()
                )
                translator.downloadModelIfNeeded(DownloadConditions.Builder().build())
                    .addOnCompleteListener { task ->
                        if (!task.isSuccessful) failed++
                        done++
                        translator.close()
                        onProgress(done, sources.size, failed)
                    }
            }
        }
    }
}
