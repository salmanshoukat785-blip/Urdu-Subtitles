package com.urdusubs.app

import android.os.Handler
import android.os.Looper
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.TranslateRemoteModel
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

/**
 * Translates a caption line to Urdu.
 *
 * Online mode asks Google Translate's public web endpoint (better quality). To keep the
 * subtitle close to the voice it also starts the on-device translation at the same time, if
 * that language's models are already on the phone: the quick on-device result is shown first
 * and replaced by the online one when it arrives. If online fails, the on-device result stays.
 *
 * The callback gets (result, isFinal). A null result with isFinal = true means nothing worked.
 * All callbacks arrive on the main thread.
 */
class UrduTranslator {

    /** Set from the app's engine choice before each translation (Prefs.ENGINE_*). */
    var engine = Prefs.ENGINE_AUTO

    private val identifier = LanguageIdentification.getClient()
    private val translators = HashMap<String, Translator>()
    private var lastLang: String? = null

    private val io = Executors.newFixedThreadPool(2)
    private val main = Handler(Looper.getMainLooper())

    private val cache = object : LinkedHashMap<String, String>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?): Boolean =
            size > 200
    }

    fun translate(text: String, onResult: (String?, Boolean) -> Unit) {
        val cached = cache[text]
        if (cached != null) {
            onResult(cached, true)
            return
        }

        if (engine == Prefs.ENGINE_OFFLINE) {
            translateOffline(text, true) { out ->
                if (out != null) cache[text] = out
                onResult(out, true)
            }
            return
        }

        if (engine == Prefs.ENGINE_ONLINE) {
            io.execute {
                val online = fetchOnline(text, "auto", "ur")
                main.post {
                    if (online != null) cache[text] = online
                    onResult(online, true)
                }
            }
            return
        }

        var onlineDone = false
        var quickShown = false

        // Quick on-device result first (only when its models are already downloaded).
        translateOffline(text, false) { out ->
            if (out != null && !onlineDone) {
                quickShown = true
                onResult(out, false)
            }
        }

        io.execute {
            val online = fetchOnline(text, "auto", "ur")
            main.post {
                onlineDone = true
                if (online != null) {
                    cache[text] = online
                    onResult(online, true)
                } else if (!quickShown) {
                    // No internet and no quick result: try on-device, downloading if needed.
                    translateOffline(text, true) { out -> onResult(out, true) }
                }
            }
        }
    }

    // ------------------------------------------------------------------- online

    /** Detects the caption's language code ("en", "hi"...); "und" when unsure. */
    fun detectLanguage(text: String, callback: (String) -> Unit) {
        identifier.identifyLanguage(text)
            .addOnSuccessListener { callback(it) }
            .addOnFailureListener { callback("und") }
    }

    /** Translates one Urdu word to English (for the tap-a-word popup). Needs internet. */
    fun urduWordToEnglish(word: String, callback: (String?) -> Unit) {
        io.execute {
            val out = fetchOnline(word, "ur", "en")
            main.post { callback(out) }
        }
    }

    private fun fetchOnline(text: String, source: String, target: String): String? {
        var connection: HttpURLConnection? = null
        try {
            val url = URL(
                "https://translate.googleapis.com/translate_a/single" +
                    "?client=gtx&sl=" + source + "&tl=" + target + "&dt=t&q=" +
                    URLEncoder.encode(text, "UTF-8")
            )
            connection = url.openConnection() as HttpURLConnection
            connection.connectTimeout = ONLINE_TIMEOUT_MS
            connection.readTimeout = ONLINE_TIMEOUT_MS
            connection.setRequestProperty("User-Agent", "Mozilla/5.0")
            if (connection.responseCode != 200) return null

            val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val parts = JSONArray(body).getJSONArray(0)
            val result = StringBuilder()
            for (i in 0 until parts.length()) {
                val part = parts.optJSONArray(i) ?: continue
                result.append(part.optString(0, ""))
            }
            val out = result.toString().trim()
            return if (out.isEmpty()) null else out
        } catch (e: Exception) {
            return null
        } finally {
            connection?.disconnect()
        }
    }

    // ------------------------------------------------------------------ offline

    /** With allowDownload = false, gives null unless the models are already on the phone. */
    private fun translateOffline(text: String, allowDownload: Boolean, callback: (String?) -> Unit) {
        identifier.identifyLanguage(text)
            .addOnSuccessListener { detected ->
                // Short caption fragments are often "und"; reuse the last known language.
                val lang = if (detected == "und") lastLang else detected
                if (lang == null) {
                    callback(null)
                    return@addOnSuccessListener
                }
                lastLang = lang

                if (lang == TranslateLanguage.URDU) {
                    callback(text)
                    return@addOnSuccessListener
                }

                val source = TranslateLanguage.fromLanguageTag(lang)
                if (source == null) {
                    callback(null)
                    return@addOnSuccessListener
                }

                if (allowDownload) {
                    runOffline(text, source, callback)
                } else {
                    whenReady(source) { ready ->
                        if (ready) runOffline(text, source, callback) else callback(null)
                    }
                }
            }
            .addOnFailureListener { callback(null) }
    }

    private fun runOffline(text: String, source: String, callback: (String?) -> Unit) {
        val translator = translators.getOrPut(source) {
            Translation.getClient(
                TranslatorOptions.Builder()
                    .setSourceLanguage(source)
                    .setTargetLanguage(TranslateLanguage.URDU)
                    .build()
            )
        }

        translator.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener {
                translator.translate(text)
                    .addOnSuccessListener { out -> callback(out) }
                    .addOnFailureListener { callback(null) }
            }
            .addOnFailureListener { callback(null) }
    }

    private fun isReady(lang: String, callback: (Boolean) -> Unit) {
        if (readyModels.contains(lang)) {
            callback(true)
            return
        }
        RemoteModelManager.getInstance()
            .isModelDownloaded(TranslateRemoteModel.Builder(lang).build())
            .addOnSuccessListener { downloaded ->
                if (downloaded) readyModels.add(lang)
                callback(downloaded)
            }
            .addOnFailureListener { callback(false) }
    }

    /** True when both the source language model and the Urdu model are on the phone. */
    private fun whenReady(source: String, callback: (Boolean) -> Unit) {
        isReady(source) { sourceReady ->
            if (!sourceReady) callback(false) else isReady(TranslateLanguage.URDU, callback)
        }
    }

    fun close() {
        io.shutdown()
        translators.values.forEach { it.close() }
        translators.clear()
        identifier.close()
    }

    companion object {
        private const val ONLINE_TIMEOUT_MS = 1500

        // Languages whose on-device model is known to be on the phone (shared by all instances).
        private val readyModels: MutableSet<String> =
            java.util.Collections.synchronizedSet(HashSet<String>())

        /** Language codes whose on-device model is installed (the Urdu model included). */
        fun downloadedModels(callback: (Set<String>) -> Unit) {
            RemoteModelManager.getInstance()
                .getDownloadedModels(TranslateRemoteModel::class.java)
                .addOnSuccessListener { models -> callback(models.map { it.language }.toSet()) }
                .addOnFailureListener { callback(emptySet()) }
        }

        /** Downloads one language's model and the Urdu model that every translation needs. */
        fun downloadModel(code: String, callback: (Boolean) -> Unit) {
            val manager = RemoteModelManager.getInstance()
            val conditions = DownloadConditions.Builder().build()
            manager.download(TranslateRemoteModel.Builder(code).build(), conditions)
                .addOnSuccessListener {
                    manager.download(
                        TranslateRemoteModel.Builder(TranslateLanguage.URDU).build(), conditions
                    )
                        .addOnSuccessListener {
                            readyModels.add(code)
                            readyModels.add(TranslateLanguage.URDU)
                            callback(true)
                        }
                        .addOnFailureListener { callback(false) }
                }
                .addOnFailureListener { callback(false) }
        }

        fun deleteModel(code: String, callback: (Boolean) -> Unit) {
            RemoteModelManager.getInstance()
                .deleteDownloadedModel(TranslateRemoteModel.Builder(code).build())
                .addOnCompleteListener { task ->
                    readyModels.remove(code)
                    callback(task.isSuccessful)
                }
        }

        /** Downloads the English, Hindi and Arabic -> Urdu models (Urdu model is shared). */
        fun downloadCommonModels(onProgress: (done: Int, total: Int, failed: Int) -> Unit) {
            val sources = listOf(
                TranslateLanguage.ENGLISH,
                TranslateLanguage.HINDI,
                TranslateLanguage.ARABIC
            )
            var done = 0
            var failed = 0
            sources.forEach { source ->
                val translator = Translation.getClient(
                    TranslatorOptions.Builder()
                        .setSourceLanguage(source)
                        .setTargetLanguage(TranslateLanguage.URDU)
                        .build()
                )
                translator.downloadModelIfNeeded(DownloadConditions.Builder().build())
                    .addOnCompleteListener { task ->
                        if (!task.isSuccessful) failed++
                        done++
                        translator.close()
                        onProgress(done, sources.size, failed)
                    }
            }
        }
    }
}
