package com.urdusubs.app

import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions

/**
 * Detects the language of a caption line and translates it to Urdu on the device.
 * All callbacks arrive on the main thread.
 */
class UrduTranslator {

    private val identifier = LanguageIdentification.getClient()
    private val translators = HashMap<String, Translator>()
    private var lastLang: String? = null

    private val cache = object : LinkedHashMap<String, String>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?): Boolean =
            size > 200
    }

    /** onResult gets the Urdu text, or null if it could not be translated. */
    fun translate(text: String, onResult: (String?) -> Unit) {
        cache[text]?.let {
            onResult(it)
            return
        }

        identifier.identifyLanguage(text)
            .addOnSuccessListener { detected ->
                // Short caption fragments are often "und"; reuse the last known language.
                val lang = if (detected == "und") lastLang else detected
                if (lang == null) {
                    onResult(null)
                    return@addOnSuccessListener
                }
                lastLang = lang

                if (lang == TranslateLanguage.URDU) {
                    onResult(text)
                    return@addOnSuccessListener
                }

                val source = TranslateLanguage.fromLanguageTag(lang)
                if (source == null) {
                    onResult(null)
                    return@addOnSuccessListener
                }

                val translator = translators.getOrPut(source) {
                    Translation.getClient(
                        TranslatorOptions.Builder()
                            .setSourceLanguage(source)
                            .setTargetLanguage(TranslateLanguage.URDU)
                            .build()
                    )
                }

                translator.downloadModelIfNeeded(DownloadConditions.Builder().build())
                    .addOnSuccessListener {
                        translator.translate(text)
                            .addOnSuccessListener { out ->
                                cache[text] = out
                                onResult(out)
                            }
                            .addOnFailureListener { onResult(null) }
                    }
                    .addOnFailureListener { onResult(null) }
            }
            .addOnFailureListener { onResult(null) }
    }

    fun close() {
        translators.values.forEach { it.close() }
        translators.clear()
        identifier.close()
    }

    companion object {
        /** Downloads the English, Hindi and Arabic -> Urdu models (Urdu model is shared). */
        fun downloadCommonModels(onProgress: (done: Int, total: Int, failed: Int) -> Unit) {
            val sources = listOf(
                TranslateLanguage.ENGLISH,
                TranslateLanguage.HINDI,
                TranslateLanguage.ARABIC
            )
            var done = 0
            var failed = 0
            sources.forEach { source ->
                val translator = Translation.getClient(
                    TranslatorOptions.Builder()
                        .setSourceLanguage(source)
                        .setTargetLanguage(TranslateLanguage.URDU)
                        .build()
                )
                translator.downloadModelIfNeeded(DownloadConditions.Builder().build())
                    .addOnCompleteListener { task ->
                        if (!task.isSuccessful) failed++
                        done++
                        translator.close()
                        onProgress(done, sources.size, failed)
                    }
            }
        }
    }
}
