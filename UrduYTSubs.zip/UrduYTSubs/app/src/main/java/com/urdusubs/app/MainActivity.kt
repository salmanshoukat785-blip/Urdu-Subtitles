package com.urdusubs.app

import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import androidx.appcompat.widget.SwitchCompat
import androidx.core.widget.addTextChangedListener

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var tvDownload: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tvStatus)
        tvDownload = findViewById(R.id.tvDownload)
        val prefs = Prefs.get(this)

        // First launch: start in Urdu. After that the user's choice is remembered.
        if (!prefs.getBoolean(Prefs.KEY_LANG_INIT, false)) {
            prefs.edit().putBoolean(Prefs.KEY_LANG_INIT, true).apply()
            AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags("ur"))
        }

        val langGroup = findViewById<android.widget.RadioGroup>(R.id.radioLang)
        val isUrdu = resources.configuration.locales[0].language == "ur"
        langGroup.check(if (isUrdu) R.id.radioUrdu else R.id.radioEnglish)
        langGroup.setOnCheckedChangeListener { _, checkedId ->
            val tag = if (checkedId == R.id.radioUrdu) "ur" else "en"
            if (resources.configuration.locales[0].language != tag) {
                AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(tag))
            }
        }

        findViewById<Button>(R.id.btnAccessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        findViewById<Button>(R.id.btnAppInfo).setOnClickListener {
            startActivity(
                Intent(
                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:$packageName")
                )
            )
        }

        findViewById<Button>(R.id.btnDownload).setOnClickListener {
            tvDownload.setText(R.string.download_progress)
            UrduTranslator.downloadCommonModels { done, total, failed ->
                if (done < total) {
                    tvDownload.text = getString(R.string.download_progress) + " $done/$total"
                } else if (failed == 0) {
                    tvDownload.setText(R.string.download_done)
                } else {
                    tvDownload.setText(R.string.download_failed)
                }
            }
        }

        val switchEnabled = findViewById<SwitchCompat>(R.id.switchEnabled)
        switchEnabled.isChecked = prefs.getBoolean(Prefs.KEY_ENABLED, true)
        switchEnabled.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(Prefs.KEY_ENABLED, checked).apply()
        }

        val switchAllApps = findViewById<SwitchCompat>(R.id.switchAllApps)
        switchAllApps.isChecked = prefs.getBoolean(Prefs.KEY_ALL_APPS, true)
        switchAllApps.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(Prefs.KEY_ALL_APPS, checked).apply()
        }

        val switchAutoHide = findViewById<SwitchCompat>(R.id.switchAutoHide)
        switchAutoHide.isChecked = prefs.getBoolean(Prefs.KEY_AUTOHIDE, true)
        switchAutoHide.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(Prefs.KEY_AUTOHIDE, checked).apply()
        }

        val editIds = findViewById<android.widget.EditText>(R.id.editIds)
        editIds.setText(prefs.getString(Prefs.KEY_CUSTOM_IDS, ""))
        editIds.addTextChangedListener { text ->
            prefs.edit().putString(Prefs.KEY_CUSTOM_IDS, text?.toString().orEmpty()).apply()
        }

        val switchOnline = findViewById<SwitchCompat>(R.id.switchOnline)
        switchOnline.isChecked = prefs.getBoolean(Prefs.KEY_ONLINE, true)
        switchOnline.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(Prefs.KEY_ONLINE, checked).apply()
        }

        val switchDebug = findViewById<SwitchCompat>(R.id.switchDebug)
        switchDebug.isChecked = prefs.getBoolean(Prefs.KEY_DEBUG, false)
        switchDebug.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(Prefs.KEY_DEBUG, checked).apply()
        }

        findViewById<Button>(R.id.btnCopyLog).setOnClickListener {
            val log = prefs.getString(Prefs.KEY_LOG, "").orEmpty()
            if (log.isEmpty()) {
                android.widget.Toast.makeText(this, R.string.toast_empty, android.widget.Toast.LENGTH_LONG).show()
            } else {
                val clipboard = getSystemService(android.content.Context.CLIPBOARD_SERVICE)
                    as android.content.ClipboardManager
                clipboard.setPrimaryClip(android.content.ClipData.newPlainText("urdu_subs_log", log))
                android.widget.Toast.makeText(this, R.string.toast_copied, android.widget.Toast.LENGTH_LONG).show()
            }
        }

        findViewById<Button>(R.id.btnClearLog).setOnClickListener {
            prefs.edit()
                .remove(Prefs.KEY_LOG)
                .putInt(Prefs.KEY_LOG_CLEARS, prefs.getInt(Prefs.KEY_LOG_CLEARS, 0) + 1)
                .apply()
            android.widget.Toast.makeText(this, R.string.toast_cleared, android.widget.Toast.LENGTH_SHORT).show()
        }

        buildColorRow(prefs)
        bindSeekBar(R.id.seekAlpha, Prefs.KEY_BG_ALPHA, 0, Prefs.DEF_BG_ALPHA)

        val modeGroup = findViewById<android.widget.RadioGroup>(R.id.radioMode)
        modeGroup.check(
            when (prefs.getInt(Prefs.KEY_MODE, Prefs.DEF_MODE)) {
                Prefs.MODE_ABOVE -> R.id.radioAbove
                Prefs.MODE_COVER -> R.id.radioCover
                else -> R.id.radioBelow
            }
        )
        modeGroup.setOnCheckedChangeListener { _, checkedId ->
            val mode = when (checkedId) {
                R.id.radioAbove -> Prefs.MODE_ABOVE
                R.id.radioCover -> Prefs.MODE_COVER
                else -> Prefs.MODE_BELOW
            }
            prefs.edit().putInt(Prefs.KEY_MODE, mode).apply()
        }
        bindSeekBar(R.id.seekShift, Prefs.KEY_SHIFT, 0, Prefs.DEF_SHIFT)

        bindSeekBar(R.id.seekSize, Prefs.KEY_SIZE, 14, Prefs.DEF_SIZE)
        bindSeekBar(R.id.seekPortrait, Prefs.KEY_POS_PORTRAIT, 0, Prefs.DEF_POS_PORTRAIT)
        bindSeekBar(R.id.seekLand, Prefs.KEY_POS_LAND, 0, Prefs.DEF_POS_LAND)
    }

    override fun onResume() {
        super.onResume()
        tvStatus.setText(if (isServiceEnabled()) R.string.status_on else R.string.status_off)
    }

    /** A row of round colour swatches; the chosen one gets a thick outline. */
    private fun buildColorRow(prefs: android.content.SharedPreferences) {
        val row = findViewById<android.widget.LinearLayout>(R.id.colorRow)
        val density = resources.displayMetrics.density
        val size = (36 * density).toInt()
        val margin = (4 * density).toInt()
        val swatches = ArrayList<android.view.View>()

        fun refresh() {
            val selected = prefs.getInt(Prefs.KEY_BG_COLOR, Prefs.DEF_BG_COLOR)
            swatches.forEachIndexed { i, view ->
                view.background = android.graphics.drawable.GradientDrawable().apply {
                    shape = android.graphics.drawable.GradientDrawable.OVAL
                    setColor(Prefs.BG_COLORS[i])
                    if (i == selected) {
                        setStroke((4 * density).toInt(), 0xFF2196F3.toInt())
                    } else {
                        setStroke((1 * density).toInt(), 0xFF888888.toInt())
                    }
                }
            }
        }

        Prefs.BG_COLORS.forEachIndexed { i, _ ->
            val swatch = android.view.View(this)
            swatch.layoutParams = android.widget.LinearLayout.LayoutParams(size, size).apply {
                setMargins(margin, margin, margin, margin)
            }
            swatch.setOnClickListener {
                prefs.edit().putInt(Prefs.KEY_BG_COLOR, i).apply()
                refresh()
            }
            swatches.add(swatch)
            row.addView(swatch)
        }
        refresh()
    }

    private fun bindSeekBar(viewId: Int, key: String, min: Int, default: Int) {
        val prefs = Prefs.get(this)
        val seekBar = findViewById<SeekBar>(viewId)
        seekBar.progress = prefs.getInt(key, default) - min
        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) prefs.edit().putInt(key, progress + min).apply()
            }

            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })
    }

    private fun isServiceEnabled(): Boolean {
        val component = ComponentName(this, SubtitleService::class.java)
        val enabled = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.split(':').any {
            it.equals(component.flattenToString(), ignoreCase = true) ||
                it.equals(component.flattenToShortString(), ignoreCase = true)
        }
    }
}
