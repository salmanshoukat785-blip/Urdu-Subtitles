package com.urdusubs.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.widget.SwitchCompat
import androidx.core.os.LocaleListCompat
import androidx.core.widget.addTextChangedListener

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var tvStatus: TextView
    private lateinit var tvDownload: TextView
    private lateinit var switchEnabled: SwitchCompat

    // Appearance controls edit the settings of one "profile": "" = default, or an app's package.
    private var uiProfile = ""
    private var binding = false
    private val refreshers = ArrayList<() -> Unit>()
    private var profilePackages: List<String> = emptyList()

    // Text waiting to be written to a file the user is about to choose.
    private var pendingText = ""

    private val exportSrt = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/x-subrip")
    ) { uri -> writeToUri(uri) }
    private val exportTxt = registerForActivityResult(
        ActivityResultContracts.CreateDocument("text/plain")
    ) { uri -> writeToUri(uri) }
    private val exportBackup = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri -> writeToUri(uri) }
    private val importBackup = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> restoreFromUri(uri) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = Prefs.get(this)
        tvStatus = findViewById(R.id.tvStatus)
        tvDownload = findViewById(R.id.tvDownload)
        switchEnabled = findViewById(R.id.switchEnabled)

        // Move mode is only for a moment; start every visit with it off.
        prefs.edit().putBoolean(Prefs.KEY_MOVE_MODE, false).apply()
        History.load(this)

        val firstLaunch = !prefs.getBoolean(Prefs.KEY_LANG_INIT, false)
        setupLanguage()
        setupButtons()
        setupSwitches()
        setupDictionary()
        setupAppearance()
        setupProfileSpinner()
        setupExtras()

        // The very first launch restarts once to apply the language; show the guide after that.
        if (!firstLaunch && !prefs.getBoolean(Prefs.KEY_GUIDE_DONE, false)) showGuide()
    }

    override fun onResume() {
        super.onResume()
        tvStatus.setText(if (isServiceEnabled()) R.string.status_on else R.string.status_off)
        // The Quick Settings tile may have changed this while the app was in the background.
        switchEnabled.isChecked = prefs.getBoolean(Prefs.KEY_ENABLED, true)
        // Move mode can switch itself off (double tap or timeout) while the app is away.
        findViewById<SwitchCompat>(R.id.switchMove).isChecked =
            prefs.getBoolean(Prefs.KEY_MOVE_MODE, false)
        updateLagInfo()
    }

    // ------------------------------------------------------------------ language

    private fun setupLanguage() {
        // First launch: start in Urdu. After that the user's choice is remembered.
        if (!prefs.getBoolean(Prefs.KEY_LANG_INIT, false)) {
            prefs.edit().putBoolean(Prefs.KEY_LANG_INIT, true).apply()
            AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags("ur"))
        }

        val langGroup = findViewById<RadioGroup>(R.id.radioLang)
        val isUrdu = resources.configuration.locales[0].language == "ur"
        langGroup.check(if (isUrdu) R.id.radioUrdu else R.id.radioEnglish)
        langGroup.setOnCheckedChangeListener { _, checkedId ->
            val tag = if (checkedId == R.id.radioUrdu) "ur" else "en"
            if (resources.configuration.locales[0].language != tag) {
                AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(tag))
            }
        }
    }

    // ------------------------------------------------------------------- buttons

    private fun setupButtons() {
        findViewById<Button>(R.id.btnAccessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        findViewById<Button>(R.id.btnAppInfo).setOnClickListener {
            openAppInfo()
        }

        findViewById<Button>(R.id.btnBattery).setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e: Exception) {
                openAppInfo()
            }
        }

        findViewById<Button>(R.id.btnDownload).setOnClickListener {
            tvDownload.setText(R.string.download_progress)
            UrduTranslator.downloadCommonModels { done, total, failed ->
                if (done < total) {
                    tvDownload.text = getString(R.string.download_progress) + " $done/$total"
                } else if (failed == 0) {
                    tvDownload.setText(R.string.download_done)
                } else {
                    tvDownload.setText(R.string.download_failed)
                }
            }
        }

        findViewById<Button>(R.id.btnCopyLog).setOnClickListener {
            val log = prefs.getString(Prefs.KEY_LOG, "").orEmpty()
            if (log.isEmpty()) {
                Toast.makeText(this, R.string.toast_empty, Toast.LENGTH_LONG).show()
            } else {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("urdu_subs_log", log))
                Toast.makeText(this, R.string.toast_copied, Toast.LENGTH_LONG).show()
            }
        }

        findViewById<Button>(R.id.btnClearLog).setOnClickListener {
            prefs.edit()
                .remove(Prefs.KEY_LOG)
                .putInt(Prefs.KEY_LOG_CLEARS, prefs.getInt(Prefs.KEY_LOG_CLEARS, 0) + 1)
                .apply()
            Toast.makeText(this, R.string.toast_cleared, Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.btnResetPos).setOnClickListener {
            prefs.edit()
                .putInt(Prefs.key(Prefs.KEY_DX, uiProfile), 0)
                .putInt(Prefs.key(Prefs.KEY_DY, uiProfile), 0)
                .apply()
            Toast.makeText(this, R.string.toast_reset_pos, Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.btnResetApp).setOnClickListener {
            if (uiProfile.isNotEmpty()) {
                val editor = prefs.edit()
                for (base in Prefs.PROFILE_KEYS) editor.remove(Prefs.key(base, uiProfile))
                editor.apply()
                refreshAll()
                Toast.makeText(this, R.string.toast_reset_app, Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun openAppInfo() {
        startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
        )
    }

    // ------------------------------------------------------------------ switches

    private fun setupSwitches() {
        switchEnabled.isChecked = prefs.getBoolean(Prefs.KEY_ENABLED, true)
        switchEnabled.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(Prefs.KEY_ENABLED, checked).apply()
        }

        bindGlobalSwitch(R.id.switchAutoHide, Prefs.KEY_AUTOHIDE, true)
        bindGlobalSwitch(R.id.switchAllApps, Prefs.KEY_ALL_APPS, true)
        bindGlobalSwitch(R.id.switchSkipUrdu, Prefs.KEY_SKIP_URDU, true)
        bindGlobalSwitch(R.id.switchFloat, Prefs.KEY_FLOAT_BTN, false)
        bindGlobalSwitch(R.id.switchTapWord, Prefs.KEY_TAP_WORD, false)
        bindGlobalSwitch(R.id.switchHistory, Prefs.KEY_HISTORY, true)
        bindGlobalSwitch(R.id.switchContext, Prefs.KEY_CONTEXT, true)
        bindGlobalSwitch(R.id.switchDebug, Prefs.KEY_DEBUG, false)
        bindGlobalSwitch(R.id.switchMove, Prefs.KEY_MOVE_MODE, false)

        val editIds = findViewById<EditText>(R.id.editIds)
        editIds.setText(prefs.getString(Prefs.KEY_CUSTOM_IDS, ""))
        editIds.addTextChangedListener { text ->
            prefs.edit().putString(Prefs.KEY_CUSTOM_IDS, text?.toString().orEmpty()).apply()
        }
    }

    private fun bindGlobalSwitch(viewId: Int, key: String, default: Boolean) {
        val toggle = findViewById<SwitchCompat>(viewId)
        toggle.isChecked = prefs.getBoolean(key, default)
        toggle.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(key, checked).apply()
        }
    }

    private fun setupDictionary() {
        val editDict = findViewById<EditText>(R.id.editDict)
        editDict.setText(prefs.getString(Prefs.KEY_DICT, ""))
        editDict.addTextChangedListener { text ->
            prefs.edit().putString(Prefs.KEY_DICT, text?.toString().orEmpty()).apply()
        }
    }

    // ---------------------------------------------------------------- appearance

    private fun setupAppearance() {
        bindSeekBar(R.id.seekSize, Prefs.KEY_SIZE, 14, Prefs.DEF_SIZE, true)
        bindSeekBar(R.id.seekShift, Prefs.KEY_SHIFT, 0, Prefs.DEF_SHIFT, true)
        bindSeekBar(R.id.seekAlpha, Prefs.KEY_BG_ALPHA, 0, Prefs.DEF_BG_ALPHA, true)
        bindSeekBar(R.id.seekHold, Prefs.KEY_HOLD, 1, Prefs.DEF_HOLD, true)
        bindSeekBar(R.id.seekPortrait, Prefs.KEY_POS_PORTRAIT, 0, Prefs.DEF_POS_PORTRAIT, false)
        bindSeekBar(R.id.seekLand, Prefs.KEY_POS_LAND, 0, Prefs.DEF_POS_LAND, false)

        bindSwatches(R.id.colorRow, Prefs.BG_COLORS, Prefs.KEY_BG_COLOR, Prefs.DEF_BG_COLOR, false)
        bindSwatches(R.id.textColorRow, Prefs.TEXT_COLORS, Prefs.KEY_TEXT_COLOR, Prefs.DEF_TEXT_COLOR, true)

        bindProfileSwitch(R.id.switchBold, Prefs.KEY_BOLD)
        bindProfileSwitch(R.id.switchShadow, Prefs.KEY_SHADOW)
        bindModeGroup()
        bindFontGroup()
    }

    /** Appearance value for the profile being edited (falls back to the default profile). */
    private fun readInt(key: String, default: Int, profileAware: Boolean): Int =
        if (profileAware) Prefs.getInt(prefs, key, uiProfile, default) else prefs.getInt(key, default)

    private fun writeInt(key: String, value: Int, profileAware: Boolean) {
        val k = if (profileAware) Prefs.key(key, uiProfile) else key
        prefs.edit().putInt(k, value).apply()
    }

    private fun refreshAll() {
        binding = true
        for (refresh in refreshers) refresh()
        binding = false
    }

    private fun bindSeekBar(viewId: Int, key: String, min: Int, default: Int, profileAware: Boolean) {
        val seekBar = findViewById<SeekBar>(viewId)
        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser && !binding) writeInt(key, progress + min, profileAware)
            }

            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })
        val refresh = { seekBar.progress = readInt(key, default, profileAware) - min }
        refreshers.add(refresh)
        refresh()
    }

    private fun bindProfileSwitch(viewId: Int, key: String) {
        val toggle = findViewById<SwitchCompat>(viewId)
        toggle.setOnCheckedChangeListener { _, checked ->
            if (!binding) prefs.edit().putBoolean(Prefs.key(key, uiProfile), checked).apply()
        }
        val refresh = { toggle.isChecked = Prefs.getBool(prefs, key, uiProfile, false) }
        refreshers.add(refresh)
        refresh()
    }

    private fun bindModeGroup() {
        val group = findViewById<RadioGroup>(R.id.radioMode)
        group.setOnCheckedChangeListener { _, checkedId ->
            if (!binding) {
                val mode = when (checkedId) {
                    R.id.radioAbove -> Prefs.MODE_ABOVE
                    R.id.radioCover -> Prefs.MODE_COVER
                    else -> Prefs.MODE_BELOW
                }
                writeInt(Prefs.KEY_MODE, mode, true)
            }
        }
        val refresh = {
            group.check(
                when (readInt(Prefs.KEY_MODE, Prefs.DEF_MODE, true)) {
                    Prefs.MODE_ABOVE -> R.id.radioAbove
                    Prefs.MODE_COVER -> R.id.radioCover
                    else -> R.id.radioBelow
                }
            )
        }
        refreshers.add(refresh)
        refresh()
    }

    private fun bindFontGroup() {
        val group = findViewById<RadioGroup>(R.id.radioFont)
        group.setOnCheckedChangeListener { _, checkedId ->
            if (!binding) {
                writeInt(
                    Prefs.KEY_FONT,
                    if (checkedId == R.id.radioFontNastaliq) Prefs.FONT_NASTALIQ else Prefs.FONT_DEFAULT,
                    true
                )
            }
        }
        val refresh = {
            group.check(
                if (readInt(Prefs.KEY_FONT, Prefs.FONT_DEFAULT, true) == Prefs.FONT_NASTALIQ)
                    R.id.radioFontNastaliq else R.id.radioFontDefault
            )
        }
        refreshers.add(refresh)
        refresh()
    }

    /** A row of round colour swatches; the chosen one gets a thick outline. */
    private fun bindSwatches(rowId: Int, colors: IntArray, key: String, default: Int, autoFirst: Boolean) {
        val row = findViewById<LinearLayout>(rowId)
        val density = resources.displayMetrics.density
        val size = (36 * density).toInt()
        val margin = (4 * density).toInt()
        val swatches = ArrayList<TextView>()

        val refresh = {
            val selected = readInt(key, default, true)
            for (i in swatches.indices) {
                val fill = if (autoFirst && i == 0) 0xFFEEEEEE.toInt() else colors[i]
                swatches[i].background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(fill)
                    if (i == selected) {
                        setStroke((4 * density).toInt(), 0xFF2196F3.toInt())
                    } else {
                        setStroke((1 * density).toInt(), 0xFF888888.toInt())
                    }
                }
            }
        }

        for (i in colors.indices) {
            val swatch = TextView(this)
            swatch.layoutParams = LinearLayout.LayoutParams(size, size).apply {
                setMargins(margin, margin, margin, margin)
            }
            swatch.gravity = Gravity.CENTER
            if (autoFirst && i == 0) {
                swatch.text = "A"
                swatch.setTextColor(Color.BLACK)
            }
            swatch.setOnClickListener {
                writeInt(key, i, true)
                refresh()
            }
            swatches.add(swatch)
            row.addView(swatch)
        }
        refreshers.add(refresh)
        refresh()
    }

    // ------------------------------------------------------------ per-app profiles

    private fun setupProfileSpinner() {
        val spinner = findViewById<Spinner>(R.id.spinnerProfile)
        val resetButton = findViewById<Button>(R.id.btnResetApp)

        val seen = HashSet<String>(prefs.getStringSet(Prefs.KEY_SEEN_APPS, emptySet()).orEmpty())
        seen.add("com.google.android.youtube")
        profilePackages = seen.sorted()

        val names = ArrayList<String>()
        names.add(getString(R.string.profile_default))
        for (pkg in profilePackages) names.add(appLabel(pkg))

        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                uiProfile = if (position == 0) "" else profilePackages[position - 1]
                resetButton.visibility = if (uiProfile.isEmpty()) View.GONE else View.VISIBLE
                refreshAll()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun appLabel(pkg: String): String {
        return try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }
    }

    // ------------------------------------------------------------------- extras

    private fun uiLocale() = resources.configuration.locales[0]

    private fun setupExtras() {
        setupEngineGroup()
        updateLanguageSummary()

        findViewById<Button>(R.id.btnLanguages).setOnClickListener { showLanguagePicker() }
        findViewById<Button>(R.id.btnModels).setOnClickListener { showModelManager() }
        findViewById<Button>(R.id.btnHistory).setOnClickListener { showHistory() }
        findViewById<Button>(R.id.btnGuide).setOnClickListener { showGuide() }

        findViewById<Button>(R.id.btnBackup).setOnClickListener {
            pendingText = Backup.export(prefs)
            exportBackup.launch("urdu_subtitles_settings.json")
        }
        findViewById<Button>(R.id.btnRestore).setOnClickListener {
            importBackup.launch(arrayOf("*/*"))
        }
    }

    private fun setupEngineGroup() {
        val group = findViewById<RadioGroup>(R.id.radioEngine)
        val current = prefs.getInt(
            Prefs.KEY_ENGINE,
            if (prefs.getBoolean(Prefs.KEY_ONLINE, true)) Prefs.ENGINE_AUTO else Prefs.ENGINE_OFFLINE
        )
        group.check(
            when (current) {
                Prefs.ENGINE_ONLINE -> R.id.radioEngOnline
                Prefs.ENGINE_OFFLINE -> R.id.radioEngOffline
                else -> R.id.radioEngAuto
            }
        )
        group.setOnCheckedChangeListener { _, checkedId ->
            val engine = when (checkedId) {
                R.id.radioEngOnline -> Prefs.ENGINE_ONLINE
                R.id.radioEngOffline -> Prefs.ENGINE_OFFLINE
                else -> Prefs.ENGINE_AUTO
            }
            prefs.edit().putInt(Prefs.KEY_ENGINE, engine).apply()
        }
    }

    // ---- language filter

    private fun selectedLanguages(): Set<String> =
        prefs.getString(Prefs.KEY_LANGS, "").orEmpty()
            .split(',').map { it.trim() }.filter { it.isNotEmpty() }.toSet()

    private fun updateLanguageSummary() {
        val selected = selectedLanguages()
        findViewById<TextView>(R.id.tvLanguages).text =
            if (selected.isEmpty()) {
                getString(R.string.langs_all_summary)
            } else {
                Languages.CODES.filter { it in selected }
                    .joinToString("، ") { Languages.name(it, uiLocale()) }
            }
    }

    private fun showLanguagePicker() {
        val codes = Languages.CODES
        val names = codes.map { Languages.name(it, uiLocale()) }.toTypedArray()
        val selected = selectedLanguages()
        val checked = BooleanArray(codes.size) { codes[it] in selected }
        AlertDialog.Builder(this)
            .setTitle(R.string.btn_languages)
            .setMultiChoiceItems(names, checked) { _, index, isChecked -> checked[index] = isChecked }
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val chosen = codes.filterIndexed { i, _ -> checked[i] }
                prefs.edit().putString(Prefs.KEY_LANGS, chosen.joinToString(",")).apply()
                updateLanguageSummary()
            }
            .setNeutralButton(R.string.langs_all_btn) { _, _ ->
                prefs.edit().putString(Prefs.KEY_LANGS, "").apply()
                updateLanguageSummary()
            }
            .show()
    }

    // ---- model manager

    private fun showModelManager() {
        UrduTranslator.downloadedModels { have ->
            val codes = Languages.CODES
            val names = codes.map { Languages.name(it, uiLocale()) }.toTypedArray()
            val checked = BooleanArray(codes.size) { codes[it] in have }
            AlertDialog.Builder(this)
                .setTitle(R.string.btn_models)
                .setMultiChoiceItems(names, checked) { _, index, isChecked ->
                    val name = names[index]
                    checked[index] = isChecked
                    if (isChecked) {
                        Toast.makeText(
                            this, getString(R.string.toast_model_downloading, name), Toast.LENGTH_SHORT
                        ).show()
                        UrduTranslator.downloadModel(codes[index]) { ok ->
                            Toast.makeText(
                                this,
                                getString(if (ok) R.string.toast_model_ready else R.string.toast_model_failed, name),
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    } else {
                        UrduTranslator.deleteModel(codes[index]) {
                            Toast.makeText(
                                this, getString(R.string.toast_model_deleted, name), Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                }
                .setPositiveButton(android.R.string.ok, null)
                .show()
        }
    }

    // ---- history

    private fun updateLagInfo() {
        val (count, average) = History.averageLatency()
        findViewById<TextView>(R.id.tvLag).text =
            if (count == 0) getString(R.string.lag_none) else getString(R.string.lag_info, count, average)
    }

    private fun showHistory() {
        val list = History.snapshot()
        val body = TextView(this)
        val pad = (16 * resources.displayMetrics.density).toInt()
        body.setPadding(pad, pad, pad, pad)
        body.setTextIsSelectable(true)
        val (count, average) = History.averageLatency()
        body.text = if (list.isEmpty()) {
            getString(R.string.history_empty)
        } else {
            val head = if (count == 0) "" else getString(R.string.lag_info, count, average) + "\n\n"
            head + list.takeLast(100).reversed().joinToString("\n\n") { it.original + "\n" + it.urdu }
        }
        val scroll = ScrollView(this)
        scroll.addView(body)

        AlertDialog.Builder(this)
            .setTitle(R.string.btn_history)
            .setView(scroll)
            .setPositiveButton(R.string.history_srt) { _, _ ->
                if (list.isEmpty()) {
                    Toast.makeText(this, R.string.history_empty, Toast.LENGTH_SHORT).show()
                } else {
                    pendingText = History.toSrt(list)
                    exportSrt.launch("urdu_subtitles.srt")
                }
            }
            .setNeutralButton(R.string.history_txt) { _, _ ->
                if (list.isEmpty()) {
                    Toast.makeText(this, R.string.history_empty, Toast.LENGTH_SHORT).show()
                } else {
                    pendingText = History.toText(list)
                    exportTxt.launch("urdu_subtitles.txt")
                }
            }
            .setNegativeButton(R.string.history_clear) { _, _ ->
                History.clear(this)
                updateLagInfo()
                Toast.makeText(this, R.string.toast_history_cleared, Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    // ---- files: export and restore

    private fun writeToUri(uri: Uri?) {
        if (uri == null) return
        try {
            contentResolver.openOutputStream(uri)?.use { it.write(pendingText.toByteArray(Charsets.UTF_8)) }
            Toast.makeText(this, R.string.toast_saved, Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, R.string.toast_save_failed, Toast.LENGTH_LONG).show()
        }
    }

    private fun restoreFromUri(uri: Uri?) {
        if (uri == null) return
        try {
            val json = contentResolver.openInputStream(uri)?.use {
                it.readBytes().toString(Charsets.UTF_8)
            } ?: throw IllegalStateException("empty")
            val count = Backup.restore(prefs, json)
            Toast.makeText(this, getString(R.string.toast_restored, count), Toast.LENGTH_LONG).show()
            recreate()
        } catch (e: Exception) {
            Toast.makeText(this, R.string.toast_restore_failed, Toast.LENGTH_LONG).show()
        }
    }

    // ---- first-run guide

    private fun showGuide() {
        AlertDialog.Builder(this)
            .setTitle(R.string.guide_title)
            .setMessage(R.string.guide_text)
            .setPositiveButton(android.R.string.ok, null)
            .setNeutralButton(R.string.btn_accessibility) { _, _ ->
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            .setOnDismissListener { prefs.edit().putBoolean(Prefs.KEY_GUIDE_DONE, true).apply() }
            .show()
    }

    // -------------------------------------------------------------------- status

    private fun isServiceEnabled(): Boolean {
        val component = ComponentName(this, SubtitleService::class.java)
        val enabled = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.split(':').any {
            it.equals(component.flattenToString(), ignoreCase = true) ||
                it.equals(component.flattenToShortString(), ignoreCase = true)
        }
    }
}
