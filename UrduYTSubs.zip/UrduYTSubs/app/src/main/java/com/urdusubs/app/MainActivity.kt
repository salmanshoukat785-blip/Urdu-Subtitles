package com.urdusubs.app

import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var tvDownload: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tvStatus)
        tvDownload = findViewById(R.id.tvDownload)
        val prefs = Prefs.get(this)

        findViewById<Button>(R.id.btnAccessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        findViewById<Button>(R.id.btnAppInfo).setOnClickListener {
            startActivity(
                Intent(
                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:$packageName")
                )
            )
        }

        findViewById<Button>(R.id.btnDownload).setOnClickListener {
            tvDownload.setText(R.string.download_progress)
            UrduTranslator.downloadCommonModels { done, total, failed ->
                if (done < total) {
                    tvDownload.text = getString(R.string.download_progress) + " $done/$total"
                } else if (failed == 0) {
                    tvDownload.setText(R.string.download_done)
                } else {
                    tvDownload.setText(R.string.download_failed)
                }
            }
        }

        val switchEnabled = findViewById<SwitchCompat>(R.id.switchEnabled)
        switchEnabled.isChecked = prefs.getBoolean(Prefs.KEY_ENABLED, true)
        switchEnabled.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(Prefs.KEY_ENABLED, checked).apply()
        }

        val switchDebug = findViewById<SwitchCompat>(R.id.switchDebug)
        switchDebug.isChecked = prefs.getBoolean(Prefs.KEY_DEBUG, false)
        switchDebug.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(Prefs.KEY_DEBUG, checked).apply()
        }

        findViewById<Button>(R.id.btnCopyLog).setOnClickListener {
            val log = prefs.getString(Prefs.KEY_LOG, "").orEmpty()
            if (log.isEmpty()) {
                android.widget.Toast.makeText(this, R.string.toast_empty, android.widget.Toast.LENGTH_LONG).show()
            } else {
                val clipboard = getSystemService(android.content.Context.CLIPBOARD_SERVICE)
                    as android.content.ClipboardManager
                clipboard.setPrimaryClip(android.content.ClipData.newPlainText("urdu_subs_log", log))
                android.widget.Toast.makeText(this, R.string.toast_copied, android.widget.Toast.LENGTH_LONG).show()
            }
        }

        findViewById<Button>(R.id.btnClearLog).setOnClickListener {
            prefs.edit()
                .remove(Prefs.KEY_LOG)
                .putInt(Prefs.KEY_LOG_CLEARS, prefs.getInt(Prefs.KEY_LOG_CLEARS, 0) + 1)
                .apply()
            android.widget.Toast.makeText(this, R.string.toast_cleared, android.widget.Toast.LENGTH_SHORT).show()
        }

        bindSeekBar(R.id.seekSize, Prefs.KEY_SIZE, 14, Prefs.DEF_SIZE)
        bindSeekBar(R.id.seekPortrait, Prefs.KEY_POS_PORTRAIT, 0, Prefs.DEF_POS_PORTRAIT)
        bindSeekBar(R.id.seekLand, Prefs.KEY_POS_LAND, 0, Prefs.DEF_POS_LAND)
    }

    override fun onResume() {
        super.onResume()
        tvStatus.setText(if (isServiceEnabled()) R.string.status_on else R.string.status_off)
    }

    private fun bindSeekBar(viewId: Int, key: String, min: Int, default: Int) {
        val prefs = Prefs.get(this)
        val seekBar = findViewById<SeekBar>(viewId)
        seekBar.progress = prefs.getInt(key, default) - min
        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) prefs.edit().putInt(key, progress + min).apply()
            }

            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })
    }

    private fun isServiceEnabled(): Boolean {
        val component = ComponentName(this, SubtitleService::class.java)
        val enabled = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.split(':').any {
            it.equals(component.flattenToString(), ignoreCase = true) ||
                it.equals(component.flattenToShortString(), ignoreCase = true)
        }
    }
}
