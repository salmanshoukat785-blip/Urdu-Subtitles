package com.urdusubs.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer

/**
 * Listens to the sound the phone is playing (other apps' audio, Android 10+), turns English
 * speech into text on the phone with Vosk, and hands the text to the subtitle service through
 * SpeechBridge. Apps can forbid this kind of capture; then only silence arrives.
 */
class AudioCaptureService : Service() {

    private val main = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var record: AudioRecord? = null
    private var thread: Thread? = null

    @Volatile
    private var running = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || intent.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (running) return START_NOT_STICKY

        goForeground(getString(R.string.audio_notif_text))

        val code = intent.getIntExtra(EXTRA_CODE, 0)
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(EXTRA_DATA)
        }
        if (data == null || Build.VERSION.SDK_INT < 29 || !ModelStore.isReady(this)) {
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val mp = manager.getMediaProjection(code, data)
            mp.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    main.post { stopSelf() }
                }
            }, main)
            projection = mp
            startListening(mp)
        } catch (e: Exception) {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    @android.annotation.SuppressLint("NewApi")
    private fun startListening(mp: MediaProjection) {
        val config = AudioPlaybackCaptureConfiguration.Builder(mp)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .build()
        val format = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(SAMPLE_RATE)
            .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
            .build()
        val minBuffer = AudioRecord.getMinBufferSize(
            SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val audio = AudioRecord.Builder()
            .setAudioPlaybackCaptureConfig(config)
            .setAudioFormat(format)
            .setBufferSizeInBytes(maxOf(minBuffer, SAMPLE_RATE * 2))
            .build()
        if (audio.state != AudioRecord.STATE_INITIALIZED) {
            audio.release()
            stopSelf()
            return
        }
        record = audio
        running = true
        SpeechBridge.running = true

        thread = Thread({ listenLoop(audio) }, "audio-subtitles").also { it.start() }
    }

    /** Runs on its own thread: audio in, text out. */
    private fun listenLoop(audio: AudioRecord) {
        var model: Model? = null
        var recognizer: Recognizer? = null
        try {
            model = Model(ModelStore.modelDir(this).absolutePath)
            recognizer = Recognizer(model, SAMPLE_RATE.toFloat())
            audio.startRecording()

            val buffer = ByteArray(3200) // 100 ms of sound
            var lastPartial = ""
            val startedAt = System.currentTimeMillis()
            var heardSound = false
            var warned = false

            while (running) {
                val n = audio.read(buffer, 0, buffer.size)
                if (n < 0) break
                if (n == 0) continue

                if (!heardSound) {
                    for (i in 0 until n) {
                        if (buffer[i].toInt() != 0) {
                            heardSound = true
                            break
                        }
                    }
                    // Nothing but silence for a while: paused video, or the app blocks capture.
                    if (!heardSound && !warned && System.currentTimeMillis() - startedAt > SILENCE_WARN_MS) {
                        warned = true
                        main.post { if (running) goForeground(getString(R.string.audio_notif_silent)) }
                    }
                } else if (warned) {
                    warned = false
                    main.post { if (running) goForeground(getString(R.string.audio_notif_text)) }
                }

                if (recognizer.acceptWaveForm(buffer, n)) {
                    val text = JSONObject(recognizer.result).optString("text").trim()
                    lastPartial = ""
                    if (text.isNotEmpty()) post(text, true)
                } else {
                    val partial = JSONObject(recognizer.partialResult).optString("partial").trim()
                    if (partial.isNotEmpty() && partial != lastPartial) {
                        lastPartial = partial
                        post(partial, false)
                    }
                }
            }
        } catch (e: Exception) {
            // Model or audio problem: stop quietly; the app shows the service as stopped.
        } finally {
            try {
                audio.stop()
            } catch (e: Exception) {
                // Never started.
            }
            audio.release()
            recognizer?.close()
            model?.close()
            main.post { stopSelf() }
        }
    }

    private fun post(text: String, isFinal: Boolean) {
        main.post { SpeechBridge.listener?.invoke(text, isFinal) }
    }

    // ---------------------------------------------------------------- notification

    private fun goForeground(text: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL, getString(R.string.audio_channel), NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, AudioCaptureService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notification = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_tile)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, getString(R.string.audio_notif_stop), stop).build())
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    override fun onDestroy() {
        running = false
        SpeechBridge.running = false
        try {
            projection?.stop()
        } catch (e: Exception) {
            // Already stopped.
        }
        projection = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.urdusubs.app.STOP_AUDIO"
        const val EXTRA_CODE = "projection_code"
        const val EXTRA_DATA = "projection_data"
        private const val CHANNEL = "audio_subtitles"
        private const val NOTIF_ID = 42
        private const val SAMPLE_RATE = 16000
        private const val SILENCE_WARN_MS = 15000L
    }
}
