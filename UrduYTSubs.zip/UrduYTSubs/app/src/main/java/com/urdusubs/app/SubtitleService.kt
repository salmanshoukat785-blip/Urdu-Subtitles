package com.urdusubs.app

import android.accessibilityservice.AccessibilityService
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView

/**
 * Watches the YouTube app, reads the caption text it shows, translates it to Urdu
 * and draws the result in an overlay on top of the video.
 */
class SubtitleService : AccessibilityService() {

    private lateinit var windowManager: WindowManager
    private var overlay: TextView? = null
    private var overlayParams: WindowManager.LayoutParams? = null

    private val translator = UrduTranslator()
    private val handler = Handler(Looper.getMainLooper())
    private val hideTask = Runnable { removeOverlay() }

    private var lastText = ""
    private var sequence = 0

    override fun onServiceConnected() {
        super.onServiceConnected()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.packageName?.toString() != YOUTUBE) return

        val prefs = Prefs.get(this)
        if (!prefs.getBoolean(Prefs.KEY_ENABLED, true)) {
            removeOverlay()
            return
        }

        val root = rootInActiveWindow ?: return
        val debug = prefs.getBoolean(Prefs.KEY_DEBUG, false)

        val found = ArrayList<String>()
        collect(root, debug, found, 0)
        if (found.isEmpty()) return

        val text = if (debug) {
            found.take(8).joinToString("\n")
        } else {
            found.joinToString(" ").trim()
        }
        if (text.isEmpty()) return

        // Keep the overlay alive while captions keep coming.
        handler.removeCallbacks(hideTask)
        handler.postDelayed(hideTask, HIDE_AFTER_MS)

        if (text == lastText) return
        lastText = text

        if (debug) {
            show(text)
            return
        }

        val mySequence = ++sequence
        translator.translate(text) { urdu ->
            if (mySequence != sequence) return@translate // a newer caption arrived
            // If translation fails, show the original so the user can tell something is wrong.
            show(urdu ?: text)
        }
    }

    /** Collects caption texts (or, in debug mode, every text node with its view id). */
    private fun collect(
        node: AccessibilityNodeInfo?,
        debug: Boolean,
        out: MutableList<String>,
        depth: Int
    ) {
        if (node == null || depth > MAX_DEPTH) return

        val id = node.viewIdResourceName ?: ""
        val text = node.text?.toString()?.trim().orEmpty()
        if (text.isNotEmpty()) {
            if (debug) {
                out.add(id.substringAfter(":id/", "no-id") + ": " + text.take(60))
            } else if (id.contains("subtitle", ignoreCase = true) ||
                id.contains("caption", ignoreCase = true)
            ) {
                out.add(text)
            }
        }

        for (i in 0 until node.childCount) {
            collect(node.getChild(i), debug, out, depth + 1)
        }
    }

    private fun show(text: String) {
        val prefs = Prefs.get(this)
        val view = overlay ?: createOverlay().also { overlay = it }
        view.text = text
        view.textSize = prefs.getInt(Prefs.KEY_SIZE, Prefs.DEF_SIZE).toFloat()

        val params = buildParams(prefs)
        try {
            if (view.parent == null) {
                windowManager.addView(view, params)
            } else {
                windowManager.updateViewLayout(view, params)
            }
        } catch (e: Exception) {
            // Window could not be shown right now; the next caption will try again.
        }
    }

    private fun createOverlay(): TextView {
        val metrics = resources.displayMetrics
        return TextView(this).apply {
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.argb(170, 0, 0, 0))
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            textDirection = View.TEXT_DIRECTION_RTL
            maxWidth = (metrics.widthPixels * 0.92f).toInt()
            setPadding(24, 12, 24, 12)
        }
    }

    private fun buildParams(prefs: SharedPreferences): WindowManager.LayoutParams {
        val params = overlayParams ?: WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).also {
            it.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            overlayParams = it
        }

        val landscape =
            resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val percent = if (landscape) {
            prefs.getInt(Prefs.KEY_POS_LAND, Prefs.DEF_POS_LAND)
        } else {
            prefs.getInt(Prefs.KEY_POS_PORTRAIT, Prefs.DEF_POS_PORTRAIT)
        }
        params.y = resources.displayMetrics.heightPixels * percent / 100
        return params
    }

    private fun removeOverlay() {
        handler.removeCallbacks(hideTask)
        lastText = ""
        sequence++
        val view = overlay ?: return
        try {
            if (view.parent != null) windowManager.removeView(view)
        } catch (e: Exception) {
            // Already gone.
        }
    }

    override fun onInterrupt() {
        removeOverlay()
    }

    override fun onDestroy() {
        removeOverlay()
        translator.close()
        super.onDestroy()
    }

    companion object {
        private const val YOUTUBE = "com.google.android.youtube"
        private const val HIDE_AFTER_MS = 4000L
        private const val MAX_DEPTH = 40
    }
}
