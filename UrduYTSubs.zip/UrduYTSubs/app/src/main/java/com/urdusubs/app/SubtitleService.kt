package com.urdusubs.app

import android.accessibilityservice.AccessibilityService
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView

/**
 * Watches video apps, reads the caption text they show, translates it to Urdu and draws the
 * result in an overlay next to the original caption.
 *
 * Appearance settings (size, colours, position...) can be different for each app; see Prefs.
 */
class SubtitleService : AccessibilityService() {

    private lateinit var windowManager: WindowManager
    private var overlay: TextView? = null
    private var overlayParams: WindowManager.LayoutParams? = null

    private val translator = UrduTranslator()
    private val dictionary = Dictionary()
    private val handler = Handler(Looper.getMainLooper())
    private val hideTask = Runnable {
        if (!Prefs.get(this).getBoolean(Prefs.KEY_MOVE_MODE, false)) removeOverlay()
    }

    private var lastText = ""
    private var sequence = 0
    private var prevInput = ""
    private var prevTime = 0L

    // Debug log: every text node seen on screen, newest last.
    private val debugEntries = LinkedHashMap<String, String>()
    private var seenClearCounter = 0
    private var saveScheduled = false

    private var controlsSeenAt = 0L
    private var processScheduled = false
    private var currentPkg = ""

    // Where the English caption is, per app, and where the overlay was last drawn.
    private val seenApps = HashSet<String>()
    private val anchors = HashMap<String, Rect>()
    private var lastAnchor: Rect? = null
    private var shownAnchor: Rect? = null
    private var sampleForPkg = ""

    // Dragging the overlay (move mode).
    private var dragDx = 0
    private var dragDy = 0
    private var dragging = false
    private var downX = 0f
    private var downY = 0f
    private var startDx = 0
    private var startDy = 0

    // Move mode switches itself off after a while, so the box never stays on screen by mistake.
    private val moveOffTask = Runnable {
        Prefs.get(this).edit().putBoolean(Prefs.KEY_MOVE_MODE, false).apply()
    }
    private var lastTapTime = 0L

    private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { p, key ->
        if (key == Prefs.KEY_MOVE_MODE) {
            handler.removeCallbacks(moveOffTask)
            if (p.getBoolean(Prefs.KEY_MOVE_MODE, false)) {
                handler.postDelayed(moveOffTask, MOVE_MODE_MAX_MS)
                sampleForPkg = ""
                show(getString(R.string.move_sample), lastAnchor)
            } else {
                removeOverlay()
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        Prefs.get(this).registerOnSharedPreferenceChangeListener(prefsListener)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Screens change many times a second; look at the screen at most every ~80 ms.
        if (event == null || processScheduled) return
        processScheduled = true
        handler.postDelayed({
            processScheduled = false
            processScreen()
        }, PROCESS_DELAY_MS)
    }

    private fun processScreen() {
        val prefs = Prefs.get(this)
        if (!prefs.getBoolean(Prefs.KEY_ENABLED, true)) {
            removeOverlay()
            return
        }

        val root = rootInActiveWindow ?: return
        val pkg = root.packageName?.toString() ?: return
        if (pkg == packageName) return // never read this app's own settings screen
        if (pkg != YOUTUBE && !prefs.getBoolean(Prefs.KEY_ALL_APPS, true)) return
        currentPkg = pkg

        if (pkg == YOUTUBE && prefs.getBoolean(Prefs.KEY_AUTOHIDE, true)) {
            autoHideControls(root)
        }

        if (prefs.getBoolean(Prefs.KEY_DEBUG, false)) {
            handleDebug(root, prefs)
            return
        }

        // Caption views are recognised by words in their view id: the built-in ones plus
        // any the user typed into the app (comma or space separated).
        val keywords = ArrayList<String>(listOf("subtitle", "caption"))
        prefs.getString(Prefs.KEY_CUSTOM_IDS, "").orEmpty()
            .split(',', ' ', '\n')
            .map { it.trim().lowercase() }
            .filter { it.isNotEmpty() }
            .forEach { keywords.add(it) }

        val found = ArrayList<String>()
        val captionBounds = Rect()
        collectCaptions(root, found, captionBounds, keywords, 0)

        val moveMode = prefs.getBoolean(Prefs.KEY_MOVE_MODE, false)
        if (found.isEmpty()) {
            // In move mode, show a sample box so there is something to drag.
            if (moveMode && sampleForPkg != pkg) {
                sampleForPkg = pkg
                show(getString(R.string.move_sample), anchors[pkg])
            }
            return
        }

        val text = found.joinToString(" ").trim()
        if (text.isEmpty()) return

        rememberApp(pkg)
        val anchor: Rect? = if (captionBounds.isEmpty) null else Rect(captionBounds)
        if (anchor != null) {
            anchors[pkg] = anchor
            lastAnchor = anchor
        }
        sampleForPkg = pkg

        // Keep the overlay alive while captions keep coming.
        val holdMs = Prefs.getInt(prefs, Prefs.KEY_HOLD, pkg, Prefs.DEF_HOLD) * 1000L
        handler.removeCallbacks(hideTask)
        if (!moveMode) handler.postDelayed(hideTask, holdMs)

        if (text == lastText) return
        lastText = text

        // The user's word list, then (for very short fragments) the previous caption as context.
        dictionary.update(prefs.getString(Prefs.KEY_DICT, "").orEmpty())
        val processed = dictionary.applyBefore(text)
        val now = SystemClock.uptimeMillis()
        val wordCount = processed.trim().split(WHITESPACE).size
        val useContext = prefs.getBoolean(Prefs.KEY_CONTEXT, true) &&
            wordCount <= SHORT_WORDS &&
            prevInput.isNotEmpty() &&
            now - prevTime < CONTEXT_WINDOW_MS &&
            !processed.contains(prevInput) &&
            !prevInput.contains(processed)
        val input = if (useContext) "$prevInput $processed" else processed
        prevInput = processed
        prevTime = now

        translator.onlineEnabled = prefs.getBoolean(Prefs.KEY_ONLINE, true)
        val mySequence = ++sequence

        // If the translation takes long (e.g. the model is still downloading), say so.
        val pendingHint = Runnable {
            if (mySequence == sequence) show(getString(R.string.translating_hint), anchor)
        }
        handler.postDelayed(pendingHint, PENDING_HINT_MS)

        translator.translate(input) { result, isFinal ->
            if (mySequence != sequence) return@translate // a newer caption arrived
            if (result != null) {
                handler.removeCallbacks(pendingHint)
                show(dictionary.applyAfter(result), anchor)
            } else if (isFinal) {
                // Translation failed: show the original so the user can tell something is wrong.
                handler.removeCallbacks(pendingHint)
                show(text, anchor)
            }
        }
    }

    /** Remembers which apps showed captions, so the app can offer per-app settings for them. */
    private fun rememberApp(pkg: String) {
        if (!seenApps.add(pkg)) return
        val prefs = Prefs.get(this)
        val stored = HashSet<String>(prefs.getStringSet(Prefs.KEY_SEEN_APPS, emptySet()).orEmpty())
        if (stored.add(pkg)) prefs.edit().putStringSet(Prefs.KEY_SEEN_APPS, stored).apply()
    }

    /** Normal mode: only nodes whose view id looks like a caption view. */
    private fun collectCaptions(
        node: AccessibilityNodeInfo?,
        out: MutableList<String>,
        bounds: Rect,
        keywords: List<String>,
        depth: Int
    ) {
        if (node == null || depth > MAX_DEPTH) return

        val id = node.viewIdResourceName?.lowercase() ?: ""
        val text = node.text?.toString()?.trim().orEmpty()
        if (text.isNotEmpty() && id.isNotEmpty() && keywords.any { id.contains(it) }) {
            out.add(text)
            if (bounds.isEmpty) node.getBoundsInScreen(bounds)
        }

        for (i in 0 until node.childCount) {
            collectCaptions(node.getChild(i), out, bounds, keywords, depth + 1)
        }
    }

    // ---------------------------------------------------------------- debug mode

    private fun handleDebug(root: AccessibilityNodeInfo, prefs: SharedPreferences) {
        val clears = prefs.getInt(Prefs.KEY_LOG_CLEARS, 0)
        if (clears != seenClearCounter) {
            seenClearCounter = clears
            debugEntries.clear()
        }

        collectDebug(root, 0)
        scheduleLogSave()

        handler.removeCallbacks(hideTask)
        handler.postDelayed(hideTask, 4000L)
        show("ڈیبگ: لاگ میں ${debugEntries.size} اندراج", null)
    }

    private fun collectDebug(node: AccessibilityNodeInfo?, depth: Int) {
        if (node == null || depth > MAX_DEPTH) return

        val id = node.viewIdResourceName?.substringAfter(":id/") ?: "no-id"
        val cls = node.className?.toString()?.substringAfterLast('.') ?: "?"
        val text = node.text?.toString()?.trim().orEmpty()
        val desc = node.contentDescription?.toString()?.trim().orEmpty()

        if (text.isNotEmpty() || desc.isNotEmpty()) {
            val bounds = Rect()
            node.getBoundsInScreen(bounds)
            val shown = if (text.isNotEmpty()) "text=" + text.take(80) else "desc=" + desc.take(80)
            // Nodes without an id are keyed by their text; the rest by id, so changing
            // texts (like the time bar) overwrite themselves instead of flooding the log.
            val key = if (id == "no-id") "$currentPkg|$cls|$shown" else "$currentPkg|$id|$cls"
            debugEntries.remove(key)
            debugEntries[key] = "$currentPkg | $id | $cls | x${bounds.left}-${bounds.right} " +
                "y${bounds.top}-${bounds.bottom} | vis=${node.isVisibleToUser} | $shown"
            while (debugEntries.size > MAX_LOG_ENTRIES) {
                val first = debugEntries.keys.iterator()
                first.next()
                first.remove()
            }
        }

        for (i in 0 until node.childCount) {
            collectDebug(node.getChild(i), depth + 1)
        }
    }

    private fun scheduleLogSave() {
        if (saveScheduled) return
        saveScheduled = true
        handler.postDelayed({
            saveScheduled = false
            Prefs.get(this).edit()
                .putString(Prefs.KEY_LOG, debugEntries.values.joinToString("\n"))
                .apply()
        }, 1000)
    }

    // ------------------------------------------------------------------- overlay

    /**
     * Shows [text] in the overlay. With [anchor] (the English caption's bounds, in screen
     * pixels) the overlay is placed next to it according to the chosen mode; otherwise it
     * uses the position sliders from the app.
     */
    private fun show(text: String, anchor: Rect?) {
        val prefs = Prefs.get(this)
        val pkg = currentPkg
        val view = overlay ?: createOverlay().also { overlay = it }

        if (!dragging) {
            dragDx = Prefs.getInt(prefs, Prefs.KEY_DX, pkg, 0)
            dragDy = Prefs.getInt(prefs, Prefs.KEY_DY, pkg, 0)
        }
        shownAnchor = anchor

        val metrics = resources.displayMetrics
        view.text = text
        view.textSize = Prefs.getInt(prefs, Prefs.KEY_SIZE, pkg, Prefs.DEF_SIZE).toFloat()
        view.setTypeface(
            null,
            if (Prefs.getBool(prefs, Prefs.KEY_BOLD, pkg, false)) Typeface.BOLD else Typeface.NORMAL
        )
        if (Prefs.getBool(prefs, Prefs.KEY_SHADOW, pkg, false)) {
            view.setShadowLayer(4 * metrics.density, 0f, metrics.density, Color.BLACK)
        } else {
            view.setShadowLayer(0f, 0f, 0f, Color.TRANSPARENT)
        }
        view.maxWidth = (metrics.widthPixels * 0.92f).toInt()

        val params = buildParams(prefs, view, anchor)
        try {
            if (view.parent == null) {
                windowManager.addView(view, params)
            } else {
                windowManager.updateViewLayout(view, params)
            }
        } catch (e: Exception) {
            // Window could not be shown right now; the next caption will try again.
        }
    }

    private fun createOverlay(): TextView {
        val density = resources.displayMetrics.density
        return TextView(this).apply {
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            textDirection = View.TEXT_DIRECTION_RTL
            background = GradientDrawable().apply {
                setColor(Color.argb(204, 0, 0, 0))
                cornerRadius = 4 * density
            }
            val h = (6 * density).toInt()
            val v = (3 * density).toInt()
            setPadding(h, v, h, v)
            setOnTouchListener { _, event -> onOverlayTouch(event) }
        }
    }

    /** Dragging only works in move mode; otherwise touches pass through to the video. */
    private fun onOverlayTouch(event: MotionEvent): Boolean {
        if (!Prefs.get(this).getBoolean(Prefs.KEY_MOVE_MODE, false)) return false
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dragging = true
                downX = event.rawX
                downY = event.rawY
                startDx = dragDx
                startDy = dragDy
            }
            MotionEvent.ACTION_MOVE -> {
                dragDx = startDx + (event.rawX - downX).toInt()
                dragDy = startDy + (event.rawY - downY).toInt()
                reposition()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragging = false
                savePosition()

                // A quick double tap (without dragging) ends move mode.
                val moved = Math.abs(event.rawX - downX) + Math.abs(event.rawY - downY)
                if (event.actionMasked == MotionEvent.ACTION_UP &&
                    moved < 20 * resources.displayMetrics.density
                ) {
                    val now = SystemClock.uptimeMillis()
                    if (now - lastTapTime < DOUBLE_TAP_MS) {
                        lastTapTime = 0L
                        Prefs.get(this).edit().putBoolean(Prefs.KEY_MOVE_MODE, false).apply()
                    } else {
                        lastTapTime = now
                    }
                }
            }
        }
        return true
    }

    private fun reposition() {
        val view = overlay ?: return
        if (view.parent == null) return
        try {
            windowManager.updateViewLayout(view, buildParams(Prefs.get(this), view, shownAnchor))
        } catch (e: Exception) {
            // Ignore; the next touch event tries again.
        }
    }

    private fun savePosition() {
        Prefs.get(this).edit()
            .putInt(Prefs.key(Prefs.KEY_DX, currentPkg), dragDx)
            .putInt(Prefs.key(Prefs.KEY_DY, currentPkg), dragDy)
            .apply()
        if (currentPkg.isNotEmpty()) rememberApp(currentPkg)
    }

    private fun buildParams(
        prefs: SharedPreferences,
        view: TextView,
        anchor: Rect?
    ): WindowManager.LayoutParams {
        val moveMode = prefs.getBoolean(Prefs.KEY_MOVE_MODE, false)
        val params = overlayParams ?: WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).also { overlayParams = it }

        // Touches go through to the video, except while the user is moving the box.
        params.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            (if (moveMode) 0 else WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
        params.gravity = Gravity.TOP or Gravity.LEFT

        val pkg = currentPkg
        val metrics = resources.displayMetrics
        val mode = Prefs.getInt(prefs, Prefs.KEY_MODE, pkg, Prefs.DEF_MODE)
        val cover = anchor != null && mode == Prefs.MODE_COVER

        // "Cover" mode hides the English caption: opaque and at least as big as it.
        view.minWidth = if (cover && anchor != null) anchor.width() else 0
        view.minHeight = if (cover && anchor != null) anchor.height() else 0
        applyBackground(prefs, view, cover)

        view.measure(
            View.MeasureSpec.makeMeasureSpec(view.maxWidth, View.MeasureSpec.AT_MOST),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val w = view.measuredWidth
        val h = view.measuredHeight

        var x: Int
        var y: Int
        if (anchor != null) {
            val gap = (4 * metrics.density).toInt()
            x = anchor.centerX() - w / 2
            y = when (mode) {
                Prefs.MODE_ABOVE -> anchor.top - h - gap
                Prefs.MODE_COVER -> anchor.bottom - h
                else -> anchor.bottom + gap
            }
            // Extra manual shift from the slider (middle = none, to the right = down).
            y += ((Prefs.getInt(prefs, Prefs.KEY_SHIFT, pkg, Prefs.DEF_SHIFT) - 50) *
                3 * metrics.density).toInt()
        } else {
            val landscape =
                resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
            val percent = if (landscape) {
                prefs.getInt(Prefs.KEY_POS_LAND, Prefs.DEF_POS_LAND)
            } else {
                prefs.getInt(Prefs.KEY_POS_PORTRAIT, Prefs.DEF_POS_PORTRAIT)
            }
            x = (metrics.widthPixels - w) / 2
            y = metrics.heightPixels - h - metrics.heightPixels * percent / 100
        }

        // The user's dragged offset, kept inside the screen.
        x += dragDx
        y += dragDy
        params.x = x.coerceIn(0, maxOf(0, metrics.widthPixels - w))
        params.y = y.coerceIn(0, maxOf(0, metrics.heightPixels - h))
        return params
    }

    /**
     * Applies the chosen background colour, opacity and text colour. In "cover" mode the box is
     * fully opaque so the English caption underneath stays hidden. With automatic text colour,
     * text turns black on light backgrounds (yellow, white) and white on dark ones.
     */
    private fun applyBackground(prefs: SharedPreferences, view: TextView, cover: Boolean) {
        val pkg = currentPkg
        val colors = Prefs.BG_COLORS
        val index = Prefs.getInt(prefs, Prefs.KEY_BG_COLOR, pkg, Prefs.DEF_BG_COLOR)
            .coerceIn(0, colors.size - 1)
        val rgb = colors[index]
        val percent = if (cover) 100 else Prefs.getInt(prefs, Prefs.KEY_BG_ALPHA, pkg, Prefs.DEF_BG_ALPHA)
        val alpha = percent.coerceIn(0, 100) * 255 / 100

        (view.background as? GradientDrawable)
            ?.setColor(Color.argb(alpha, Color.red(rgb), Color.green(rgb), Color.blue(rgb)))

        val textIndex = Prefs.getInt(prefs, Prefs.KEY_TEXT_COLOR, pkg, Prefs.DEF_TEXT_COLOR)
            .coerceIn(0, Prefs.TEXT_COLORS.size - 1)
        if (textIndex > 0) {
            view.setTextColor(Prefs.TEXT_COLORS[textIndex])
        } else {
            val luminance =
                (0.299 * Color.red(rgb) + 0.587 * Color.green(rgb) + 0.114 * Color.blue(rgb)) / 255.0
            // A very see-through box shows the video, so keep white text there.
            val lightBox = luminance > 0.55 && percent >= 40
            view.setTextColor(if (lightBox) Color.BLACK else Color.WHITE)
        }
    }

    /**
     * With any accessibility service on, YouTube keeps its player buttons on screen. While
     * a video is playing and the buttons have stayed visible for HIDE_CONTROLS_AFTER_MS, press
     * YouTube's own "Hide controls" button for the user. Paused videos keep their buttons.
     */
    private fun autoHideControls(root: AccessibilityNodeInfo) {
        val hideButton = root
            .findAccessibilityNodeInfosByViewId("$YOUTUBE:id/hide_controls_button_top")
            .firstOrNull { it.isVisibleToUser }
        if (hideButton == null) {
            controlsSeenAt = 0L
            return
        }

        val playButton = root
            .findAccessibilityNodeInfosByViewId("$YOUTUBE:id/player_control_play_pause_replay_button")
            .firstOrNull()
        val playing = playButton?.contentDescription?.toString()
            ?.contains("Pause", ignoreCase = true) == true
        if (!playing) {
            controlsSeenAt = 0L
            return
        }

        val now = SystemClock.uptimeMillis()
        if (controlsSeenAt == 0L) {
            controlsSeenAt = now
            return
        }
        if (now - controlsSeenAt < HIDE_CONTROLS_AFTER_MS) return

        var target: AccessibilityNodeInfo? = hideButton
        var hops = 0
        while (target != null && !target.isClickable && hops < 3) {
            target = target.parent
            hops++
        }
        target?.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        controlsSeenAt = 0L
    }

    private fun removeOverlay() {
        handler.removeCallbacks(hideTask)
        lastText = ""
        sequence++
        val view = overlay ?: return
        try {
            if (view.parent != null) windowManager.removeView(view)
        } catch (e: Exception) {
            // Already gone.
        }
    }

    override fun onInterrupt() {
        removeOverlay()
    }

    override fun onDestroy() {
        Prefs.get(this).unregisterOnSharedPreferenceChangeListener(prefsListener)
        removeOverlay()
        translator.close()
        super.onDestroy()
    }

    companion object {
        private const val YOUTUBE = "com.google.android.youtube"
        private const val PROCESS_DELAY_MS = 80L
        private const val HIDE_CONTROLS_AFTER_MS = 5000L
        private const val PENDING_HINT_MS = 2000L
        private const val MOVE_MODE_MAX_MS = 120000L
        private const val DOUBLE_TAP_MS = 400L
        private const val MAX_DEPTH = 40
        private const val MAX_LOG_ENTRIES = 300

        // Very short caption fragments are translated together with the previous caption.
        private const val SHORT_WORDS = 4
        private const val CONTEXT_WINDOW_MS = 3000L

        private val WHITESPACE = Regex("\\s+")
    }
}
