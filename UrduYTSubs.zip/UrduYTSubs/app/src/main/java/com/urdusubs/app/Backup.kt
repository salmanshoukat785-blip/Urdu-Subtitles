package com.urdusubs.app

import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/** Saves all settings to a JSON text and puts them back (e.g. on a new phone). */
object Backup {
    // Things that belong to this phone / this moment and are not worth restoring.
    private val SKIP = setOf(
        Prefs.KEY_LOG, Prefs.KEY_LOG_CLEARS, Prefs.KEY_MOVE_MODE,
        Prefs.KEY_LANG_INIT, Prefs.KEY_GUIDE_DONE
    )

    fun export(p: SharedPreferences): String {
        val root = JSONObject()
        for ((k, v) in p.all) {
            if (k in SKIP) continue
            val o = JSONObject()
            when (v) {
                is Boolean -> { o.put("t", "b"); o.put("v", v) }
                is Int -> { o.put("t", "i"); o.put("v", v) }
                is Long -> { o.put("t", "l"); o.put("v", v) }
                is Float -> { o.put("t", "f"); o.put("v", v.toDouble()) }
                is String -> { o.put("t", "s"); o.put("v", v) }
                is Set<*> -> { o.put("t", "ss"); o.put("v", JSONArray(v.map { it.toString() })) }
                else -> continue
            }
            root.put(k, o)
        }
        return root.toString(1)
    }

    /** Returns how many settings were restored; throws if the text is not a backup. */
    fun restore(p: SharedPreferences, json: String): Int {
        val root = JSONObject(json)
        val editor = p.edit()
        var count = 0
        val keys = root.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            if (k in SKIP) continue
            val o = root.optJSONObject(k) ?: continue
            when (o.optString("t")) {
                "b" -> editor.putBoolean(k, o.getBoolean("v"))
                "i" -> editor.putInt(k, o.getInt("v"))
                "l" -> editor.putLong(k, o.getLong("v"))
                "f" -> editor.putFloat(k, o.getDouble("v").toFloat())
                "s" -> editor.putString(k, o.getString("v"))
                "ss" -> {
                    val arr = o.getJSONArray("v")
                    val set = HashSet<String>()
                    for (i in 0 until arr.length()) set.add(arr.getString(i))
                    editor.putStringSet(k, set)
                }
                else -> continue
            }
            count++
        }
        editor.apply()
        return count
    }
}
